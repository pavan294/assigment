import logo from './logo.svg';
import { useState} from 'react';
import './App.css';

function App() {
  const [company, setCompany]= useState("right sol")
  const [id, setId]= useState("123")
  const [server, setServer]= useState("sql")
  const [showform, setShowform] = useState(false)
  const getForm = (e) => {
       return (
           <div> 
               <form id= "add-app">
                   <input type="text" onChange={(e)=>setCompany(e.target.value)}/>
                   <input type="text" onChange={(e)=>setId(e.target.value)}/>
                   <input onChange={(e)=>setServer(e.target.value)}/>  
              </form>
          </div>
       );
    }
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <label>Company Name : </label>
        <input type="text" placeholder={company}/>
        <label> id : </label>
        <input type="text" placeholder={id}/>

        <label>Server details : </label>
        <input placeholder={server}/> 
        <button onClick={()=>setShowform(true)}>openform</button>
        {showform ? getForm() :null}
      </header>
    </div>
  );
}

export default App;
